package ext.csharp;

public class EventArgs {
	
}
