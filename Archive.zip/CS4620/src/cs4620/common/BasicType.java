package cs4620.common;

public enum BasicType {
	Sphere,
	Cube,
	Cylinder,
	TriangleMesh
}
